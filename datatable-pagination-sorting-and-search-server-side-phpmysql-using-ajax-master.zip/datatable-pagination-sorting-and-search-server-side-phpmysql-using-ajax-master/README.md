# Datatable Pagination, Sorting And Search – Server Side (PHP/MySQl) Using Ajax

The Main benefit of Datatable is open source and light weighted jquery plugin. You can use this plugin with other CSS frameworks like bootstrap and foundation. There are a lot of datatable plugins are available which useful to improve UI experience.

https://www.phpflow.com/php/datatable-pagination-sorting-and-search-server-side-phpmysql-using-ajax/
